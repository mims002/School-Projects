//creates abstract class for Cipher
public abstract class Cipher {
	//abstract methods for encrypt and decrypt 
	public abstract String encrypt(String s);
	public abstract String decrypt(String s);
}
