// Indicates that a running game should be quit
public class QuitGameException extends RuntimeException {

}
  
