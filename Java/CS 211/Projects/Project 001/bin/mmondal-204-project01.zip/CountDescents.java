
public class CountDescents {
	
	//returns how many decents occer in the recieved int array 
	public static int countDescents (int[] xs)
	{

		int count=0;
		
		//loops through each int in array
		for (int rep=1; rep<xs.length;rep++) 
		{
			//checks if last # was higher or same 
			if (xs[rep-1]>=xs[rep] && rep<xs.length-1)	
			{
				//keeps going it its descending or same 
					continue;
			}
			//for the last item if its not a  decent 
			//it makes sure the loop doesn't skip the last count
			if (rep==xs.length-1 && xs[rep-1]<xs[rep] ) 
				count++;
			
			count++; //adds one when its not descending 
			
		}
		
		return count; //returns the final value for count
		
	}
}
