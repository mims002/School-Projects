
public class ShiftQueue{

//creats an empty array with length given and value-1
  public static int [] makeQueue(int capacity)
  {
	  //when capacity is 0 return null
	  if (capacity<0)
		  return null;
	  
	  //initializes the empty array with value 0
	  int []empty=new int[capacity];
	  
	  //loops through the created array and fills it with -1
	  for(int i=0;i<capacity;i++)
	  {
		  empty[i]=-1;
	  }
	  //returns the initialized array
	  return empty;
  }

  //adds newItem at the end of the referenced array
  public static boolean addToEndOfQueue(int [] queue, int newItem)
  {
	  //loops through the referenced array and if possible adds in the new item
	  //if not possible or the arrays is empty returns false
	  for (int i = 0; i<=queue.length-1;i++)
	  {
		  //looks for and empty slot and also makes sure a data value is passed in 
		  if (queue[i]==-1 && newItem!=-1)
		  {
			  queue[i]=newItem;
			  return true;
		  }
		  
	  }return false;
  }

  //removes the from the front of the array then moves everything up
  public static boolean removeFromFrontOfQueue(int [] queue)
  {
	  //checks the length is greater than 0 and contains actual value 
	  if (queue.length>0 && queue[0]!=-1)
	  {
		  //loops through the referenced array and moved everything up one 
		  //this deletes the first value because it is not stored anywhere 
		  for(int i=0;i<queue.length-1;i++)
		  {
			  queue[i]=queue[i+1];
		  }
		  //since the loop doesn't run on the last index it is set to -1 
		  queue[queue.length-1]=-1;
		  return true;
	  }
	  return false;
  }

  //returns the array to a string similar to Arrays.toSting method
  public static String queueString(int [] queue)
  {
	  String out="";
	  //Enhanced loops iterates through each value and adds it to the out string
	  for(int value:queue)
	  {
		  //if a value is -1 then no more data is stored so it quites
		  if (value==-1)
			  break;
		  out+=value+" ";
	  }
	  
	  return out;
  }

}