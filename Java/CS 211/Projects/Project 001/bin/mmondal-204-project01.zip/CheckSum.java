import java.util.Arrays;

public class CheckSum {
	
	// Returns Fletcher's checksum for the integers given.
	public static int [] computeCheckSum(int [] data)
	{
		//initializes the 64 bit integer into 2 arrays and the sums
		int sum1=0;
		int sum2=0;
		int []results=new int[2];
		
		//loops through the provided int array to calculate the Flechers sum 
		for(int i=0;i<=data.length-1;i++)
		{
			sum1+=data[i];
			sum2+=sum1;
		}
		//Stores each sum into the reults arrays 
		results[0]=sum1;
		results[1]=sum2;
		//returns array of integers 
		return results;
		
	}
	
	// Returns Fletcher's checksum for the String given.
	public static int [] computeCheckSum(String message)
	{
		//converts the string into an array of integer 
		//then calls computeCheckSum to create an array of int of the CheckSum
		return (computeCheckSum(RunCheckSum.stringToInts(message)));
	}
	
	 //Verifies the checksum computed from the array data matches the
	 // given expected checksum.
	public static boolean verifyCheckSum(int [] data, int [] expected)
	{
		//First the data's chack sum is calculated 
		int[]recieved=computeCheckSum(data);
		//returns True if both integers of array of the check sum matches the expected
		return recieved[0]==expected[0] && recieved[1]==expected[1];
	}
	 
	//Verifies the checksum computed from the String Message matches the
	// given expected checksum.	
	public static boolean verifyCheckSum(String message, String expectedHex)
	{
		//computes the Check Sum for the given String message 
		int []recieved = computeCheckSum(message);
		//converts expected he into integers for comparing 
		int []expected = RunCheckSum.hexStringToInts(expectedHex);
		
		//loops through the expected int with the computed int from given 
		
		for(int i=0; i<expected.length;i++)
		{
			//checks if everything matches 
			//if it doesn't match it returns false 
			if (recieved[i]!=expected[i])
					return false;
		}
		//if loops completes then return true
		return true ;
	}

}
