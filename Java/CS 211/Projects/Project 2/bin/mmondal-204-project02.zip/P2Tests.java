public class P2Tests {
  public static void main(String args[]){
    org.junit.runner.JUnitCore.main("SlopeInterceptLETests",
                                    "GeneralLETests",
                                    "ProperQueueTests");
  }
  
}
