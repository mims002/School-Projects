// Fill in the definition for this class
public class SlopeInterceptLE {
	  // Fields required for the class
	 private double x,m,b;
	  // Fill in the definitions of all methods
	  public SlopeInterceptLE(double m, double b){
		  this(m,b,0.0);
	  }
	  //constructor initializes everything 	
	  public SlopeInterceptLE(double m, double b, double x){
		  this.m=m;
		  this.x=x;
		  this.b=b;
	  }
	
	  //caclulated y
	  public double value(){
		  
	    return (m*x+b);
	  }
	  
	  //returns x
	  public double getX(){
	    return x;
	  }
	  
	  //returns calculated y
	  public double getY(){
	    return value();
	  }
	
	  //sets x
	  public void setX(double x){
	    this.x=x;
	  }
	  
	  //calulated and sets x from the passed y value
	  public void setY(double y){
		 x= (y-b)/m;
	  }
	
	  //returns the formated string 
	  public String toString(){
	    return String.format("y = %.2f * x + %.2f" , m,b);
	  }
	}
