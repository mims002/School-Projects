public class ProperQueue {
	
	//initializes class variables
	private int size;
	private Integer[]elements;
	
	//creates the number of Integer objects the elements array 
	//can hold
	public ProperQueue(int i) {
		//if a value<0 is passed then it's set to null
		this.elements=(i>0) ? new Integer[i] : null;
	}
	
	//returns the current size of values in queue 
	public int getSize()
	{
		//resets the size variable
		this.size=0;
		//inhanced loop will fail if elements is null or 0
		//makes sure there is something in the elements Integer array
		if(this.getCapacity()>0)
		{
			//loops thorugh and adds up all the none nulls
			for(Integer i:this.elements)
			{
				if (i!=null)
				{
					this.size++;
				}
			}
		}
		//using this. helps me visualize it better
		//returns the size 
		return this.size;
	}
	
	//returns the max capacity/lentht for Integer array element
	public int getCapacity() {	
		//checks if it is an array first 
		if(this.elements==null)
			return 0;
		//returns the length if it is an array
		return this.elements.length;
	}
	
	
	//checks if elements are full 
	public boolean isFull()
	{
		//checks if the last element is empty
		if (this.getCapacity()==0)
			return true;
		//returns the true if the last element is null
		return (this.elements[this.getCapacity()-1]!=null);

	}
	
	
	//checks if not full
	public boolean isEmpty()
	{
		//checks if full then not empty
		if(this.isFull())
			return false;
		//chekcs the first element in queue is empty then its empty
		return (this.elements[0]==null);
	}
	
	//returns the first value in queue
	public Integer poll()
	{
		//checks if the queue has any value
		if(this.isEmpty())
			return null;
		
		//saves the first value so it can be returned 
		Integer toRemove=this.elements[0];
		//moves all queue to the left
		for(int index =0;index<this.getSize()-1;index++){
			this.elements[index]=elements[index+1];
		}
		//sets the last value 
		this.elements[this.size-1]=null;
		return toRemove;
	}
	
	
	//adds new queue at the first empty queue 
	public boolean add(Integer i) {
		//checks if null is passed or if the queue is full then returns Exception
		if (i==null){
			throw new RuntimeException("Cannot add null");
		}
		else if(this.isFull()){
			throw new RuntimeException("Queue full");
		}
		
		//adds the passed Integer in the end
		this.elements[this.getSize()]=i;
		//if all works then returns true
		return true;	

	}
	//adds new queue at the first empty queue 
	public boolean offer(Integer i) {
		//checks if null is passed or if the queue is full then returns false
		if (i==null||this.isFull())
			return false;
		
		//adds the passed Integer in the end
		this.elements[this.getSize()]=i;
		//if all works then returns true
		return true;	

	}
	
	//removes the first value in queue 
	public Integer remove() 
	{
		//checks if there is any element to remove
		if (this.isEmpty())
		{
			throw new RuntimeException("Queue empty");
		}
		
		//saves the first value so it can be returned 
		Integer toRemove=this.elements[0];
		//removes and returns the value in the begining 
		for(int index =0;index<this.getSize()-1;index++){
			//Integer temp = elements[index];
			this.elements[index]=elements[index+1];
		}
		
		this.elements[this.size-1]=null;
		return toRemove;
	}
	
	
	public Integer element() {
		if(this.isEmpty())
			throw new RuntimeException("Queue empty");
		
		//return the first item in queue
		return this.elements[0];
		
	}
	
	public String toString()
	{
		String elements="";
		//makes sure there is something in the queue
		if(this.getCapacity()>0)
		{
			//loops thorugh and finds every queue and adds to the String
			for(Integer i:this.elements)
			{
				if(i==null)
				{
					break;
				}
				elements+=i+" "; 
			}
			//creates the end length of the elements string 
			int length= elements.length()>0 ? elements.length()-1:0;
			//removes the last space created by the loop
			elements=elements.substring(0,length);
		}
		return elements;
	}

	//variation to elements() but does not throw exception
	public Integer peek() {
		if(this.isEmpty())
			return null;
		
		//return the first item in queue
		return this.elements[0];
		
	}
	

}
